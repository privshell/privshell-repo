'use strict';
/* ORBIT // STORE WebUI */
const MOD = '/data/adb/modules/orbit_store';
const CLI = `sh ${MOD}/store.sh`;
const DEFAULT_SOURCE = 'https://modules.kernelsu.org/';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const HAS_KSU = typeof window.ksu !== 'undefined' && typeof window.ksu.exec === 'function';
const VALID_ID = /^[a-zA-Z][a-zA-Z0-9._-]{1,63}$/;
const VALID_URL = /^https:\/\/[A-Za-z0-9._~:/?#@!$&()*+,;=%-]+$/;
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------- shell bridge ---------- */
let cbn = 0;
function exec(cmd) {
  return new Promise(resolve => {
    if (!HAS_KSU) return resolve({ errno: 1, stdout: '', stderr: 'not running inside a root manager' });
    const name = `__orbit_cb_${Date.now()}_${cbn++}`;
    window[name] = (errno, stdout, stderr) => { delete window[name]; resolve({ errno, stdout: stdout || '', stderr: stderr || '' }); };
    try { window.ksu.exec(cmd, '{}', name); } catch (e) { delete window[name]; resolve({ errno: 1, stdout: '', stderr: String(e) }); }
  });
}
const cli = a => exec(`${CLI} ${a}`);
async function cliJSON(a, fb) {
  const r = await cli(a);
  const lines = r.stdout.trim().split('\n').filter(Boolean);
  try { return JSON.parse(lines[lines.length - 1]); } catch (e) { return fb; }
}
const q = s => `'${String(s).replace(/'/g, '')}'`;

/* ---------- settings (local) ---------- */
const PREF = {
  get author() { return localStorage.getItem('orbit.author') || 'kreza6173-pixel'; },
  set author(v) { localStorage.setItem('orbit.author', v); },
  get pre() { return localStorage.getItem('orbit.pre') === '1'; },
  set pre(v) { localStorage.setItem('orbit.pre', v ? '1' : '0'); }
};

/* ---------- state ---------- */
const S = {
  sources: [DEFAULT_SOURCE], modules: [], byId: new Map(), installed: new Map(), details: new Map(),
  tools: {}, tab: 'browse', q: '', sort: 'updated', tag: '', cached: false, failed: [], busy: new Set(), pendingReboot: false
};

/* ---------- ui helpers ---------- */
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600); }
function openSheet(html, bind) { $('#sheet').innerHTML = html; $('#sheetBg').classList.add('on'); $('#sheet').scrollTop = 0; if (bind) bind($('#sheet')); }
function closeSheet() { $('#sheetBg').classList.remove('on'); }
$('#sheetBg').addEventListener('click', e => { if (e.target.id === 'sheetBg') closeSheet(); });
function confirmSheet(title, text, ok, danger) {
  return new Promise(res => openSheet(`<h2>${esc(title)}</h2><p class="hint">${esc(text)}</p><div class="toolbar"><button class="${danger ? 'danger' : 'primary'}" id="cOk" style="flex:1">${esc(ok)}</button><button class="ghost" id="cNo" style="flex:1">Cancel</button></div>`, s => {
    $('#cOk', s).onclick = () => { closeSheet(); res(true); };
    $('#cNo', s).onclick = () => { closeSheet(); res(false); };
  }));
}
function hue(s) { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; }
function iconHtml(m) {
  const url = m.icon ? absUrl(m._src, m.icon) : '';
  const img = url ? `<img loading="lazy" src="${esc(url)}" onerror="this.remove()">` : '';
  return `<div class="ic" style="background:hsl(${hue(m.id)} 70% 72%)">${esc((m.name || m.id).trim().charAt(0).toUpperCase())}${img}</div>`;
}
function absUrl(base, path) {
  try { const u = new URL(path, base); return u.protocol === 'https:' ? u.href : ''; } catch (e) { return ''; }
}
function htmlToText(h) {
  if (!h) return '';
  const d = new DOMParser().parseFromString(String(h), 'text/html');
  d.querySelectorAll('li').forEach(li => li.prepend('• '));
  d.querySelectorAll('br,p,li,h1,h2,h3,h4,div,pre').forEach(el => el.append('\n'));
  return (d.body.textContent || '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
function ago(iso) {
  const s = (Date.now() - Date.parse(iso)) / 1000; if (!isFinite(s)) return '';
  if (s < 3600) return `${Math.max(1, s / 60 | 0)}m ago`; if (s < 86400) return `${s / 3600 | 0}h ago`;
  if (s < 86400 * 60) return `${s / 86400 | 0}d ago`; return new Date(iso).toLocaleDateString();
}
const authorsText = m => (m.authors || []).map(a => a.name).filter(Boolean).join(', ') || (m.starsRepository || '').split('/')[0] || 'Unknown';
function fmtSize(n) { if (!n) return ''; return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, n / 1024 | 0) + ' KB'; }

/* ---------- network ---------- */
async function getText(url) {
  if (!VALID_URL.test(url)) throw new Error('invalid url');
  const r = await cli(`get ${q(url)}`);
  let out = r.stdout;
  if (!out.includes('#ORBIT-FAILED') && out.trim()) {
    if (out.includes('#ORBIT-CACHED')) { S.cached = true; out = out.replace(/\n?#ORBIT-CACHED\s*$/, ''); }
    return out;
  }
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.text();
}
const getJSON = async url => JSON.parse(await getText(url));

/* ---------- loading ---------- */
async function loadSources() {
  const r = await cli('sources');
  const list = r.stdout.split('\n').map(s => s.trim()).filter(s => VALID_URL.test(s));
  S.sources = list.length ? list.map(s => s.endsWith('/') ? s : s + '/') : [DEFAULT_SOURCE];
}
async function loadInstalled() {
  const arr = await cliJSON('installed', []);
  S.installed = new Map();
  for (const m of arr) { const cur = S.installed.get(m.id); if (!cur || m.pending) S.installed.set(m.id, m); }
}
async function loadRegistry() {
  S.cached = false; S.failed = [];
  const all = new Map();
  await Promise.all(S.sources.map(async base => {
    try {
      const j = await getJSON(base + 'api/v1/modules.json');
      for (const m of (j.modules || [])) {
        if (!m || !VALID_ID.test(m.id || '')) continue;
        if (!all.has(m.id)) all.set(m.id, Object.assign({}, m, { _src: base }));
      }
    } catch (e) { S.failed.push(base); }
  }));
  S.modules = [...all.values()];
  S.byId = all;
}
async function loadAll() {
  $('#subline').textContent = 'Loading...';
  $('#list').innerHTML = '<div class="empty"><span class="spin"></span> Fetching modules</div>';
  S.tools = await cliJSON('tools', {});
  await loadSources();
  await Promise.all([loadInstalled(), loadRegistry()]);
  renderAll();
}

/* ---------- module state ---------- */
function stateOf(m) {
  const i = S.installed.get(m.id);
  if (S.busy.has(m.id)) return 'busy';
  if (!i) return 'none';
  if (i.pending) return 'pending';
  const rv = m.stable ? m.stable.versionCode : 0;
  return rv > i.versionCode ? 'update' : 'installed';
}
function actionBtn(m) {
  const st = stateOf(m);
  if (st === 'busy') return `<button class="act done" disabled><span class="spin"></span></button>`;
  if (st === 'update') return `<button class="act upd" data-install="${esc(m.id)}">Update</button>`;
  if (st === 'installed') return `<button class="act done" data-open="${esc(m.id)}">Installed</button>`;
  if (st === 'pending') return `<button class="act done" data-reboot="1">Reboot</button>`;
  return `<button class="act" data-install="${esc(m.id)}">Install</button>`;
}
function card(m) {
  const i = S.installed.get(m.id);
  const tags = [];
  if (m.metamodule) tags.push('<span class="chip meta">Metamodule</span>');
  if (m.stable && Date.now() - Date.parse(m.stable.publishedAt) < 3 * 86400000) tags.push('<span class="chip new">New release</span>');
  if (m.stars) tags.push(`<span class="chip">★ ${m.stars}</span>`);
  if (m.stable) tags.push(`<span class="chip">${esc(m.stable.version)}</span>`);
  if (i && stateOf(m) === 'update') tags.push(`<span class="chip">installed ${esc(i.version)}</span>`);
  return `<div class="card" data-id="${esc(m.id)}">${iconHtml(m)}<div class="meta"><div class="name">${esc(m.name || m.id)}</div><div class="by">${esc(authorsText(m))}${m.stable ? ' · ' + esc(ago(m.stable.publishedAt)) : ''}</div><div class="sum">${esc(m.summary || '')}</div><div class="row">${tags.join('')}${actionBtn(m)}</div></div></div>`;
}

/* ---------- render ---------- */
function filtered() {
  const t = S.q.trim().toLowerCase();
  let list = S.modules.filter(m => {
    if (S.tag && !(m.tags || []).includes(S.tag)) return false;
    if (!t) return true;
    return `${m.id} ${m.name} ${m.summary} ${authorsText(m)} ${(m.tags || []).join(' ')}`.toLowerCase().includes(t);
  });
  const by = { updated: (a, b) => Date.parse(b.updatedAt || 0) - Date.parse(a.updatedAt || 0), stars: (a, b) => (b.stars || 0) - (a.stars || 0), name: (a, b) => (a.name || a.id).localeCompare(b.name || b.id) };
  return list.sort(by[S.sort]);
}
function renderBrowse() {
  const list = filtered();
  const n = [];
  if (S.failed.length) n.push(`<div class="err">Could not reach ${S.failed.map(esc).join(', ')}. Check your connection or the download tools in Settings.</div>`);
  if (S.cached) n.push('<div class="warn">Showing a cached copy of the catalog. Pull Refresh when you are online.</div>');
  if (!HAS_KSU) n.push('<div class="warn">Open this page from your root manager (KernelSU, APatch or a WebUI-capable manager) to install modules.</div>');
  $('#notice').innerHTML = n.join('');
  $('#list').innerHTML = list.length ? list.map(card).join('') : '<div class="empty">No modules found.</div>';
  const counts = new Map(); S.modules.forEach(m => (m.tags || []).forEach(t => counts.set(t, (counts.get(t) || 0) + 1)));
  const tags = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 24).map(e => e[0]);
  $('#tagbar').innerHTML = `<button data-tag="" class="${S.tag ? '' : 'on'}">All</button>` + tags.map(t => `<button data-tag="${esc(t)}" class="${S.tag === t ? 'on' : ''}">${esc(t)}</button>`).join('');
}
function updates() { return S.modules.filter(m => stateOf(m) === 'update'); }
function renderInstalled() {
  const reg = S.modules.filter(m => S.installed.has(m.id));
  const ups = updates();
  const local = [...S.installed.values()].filter(i => !S.byId.has(i.id));
  $('#updHint').textContent = ups.length ? `${ups.length} update${ups.length > 1 ? 's' : ''} available` : 'Everything is up to date';
  $('#updAll').style.display = ups.length > 1 ? '' : 'none';
  const ord = reg.sort((a, b) => (stateOf(b) === 'update') - (stateOf(a) === 'update'));
  $('#instList').innerHTML = (ord.map(card).join('') +
    (local.length ? `<h4 class="hint" style="margin-top:16px">Not in the catalog</h4>` + local.map(i => `<div class="card"><div class="ic" style="background:hsl(${hue(i.id)} 30% 40%)">${esc((i.name || i.id).charAt(0).toUpperCase())}</div><div class="meta"><div class="name">${esc(i.name || i.id)}</div><div class="by">${esc(i.author)} · ${esc(i.version)}${i.state !== 'enabled' ? ' · ' + esc(i.state) : ''}${i.pending ? ' · reboot pending' : ''}</div><div class="by mono">${esc(i.id)}</div></div></div>`).join('') : '')) || '<div class="empty">No modules installed.</div>';
  const b = $('#updBadge'); b.textContent = ups.length; b.classList.toggle('on', ups.length > 0);
}
function isFeatured(m) {
  const a = PREF.author.toLowerCase(); if (!a) return false;
  return (m.authors || []).some(x => (x.name || '').toLowerCase() === a || (x.url || '').toLowerCase().replace(/\/+$/, '').endsWith('/' + a)) || (m.starsRepository || '').toLowerCase().startsWith(a + '/');
}
function renderMine() {
  const list = S.modules.filter(isFeatured);
  $('#mineList').innerHTML = list.length ? list.map(card).join('') : `<div class="empty">No modules by ${esc(PREF.author)} in the catalog yet.</div>`;
}
function renderHeader() {
  const ups = updates().length;
  $('#subline').textContent = `${S.modules.length} modules · ${S.installed.size} installed${ups ? ` · ${ups} update${ups > 1 ? 's' : ''}` : ''}`;
}
function renderAll() { renderHeader(); renderBrowse(); renderInstalled(); renderMine(); if (S.tab === 'settings') renderSettings(); }

/* ---------- events ---------- */
$('#q').addEventListener('input', e => { S.q = e.target.value; renderBrowse(); });
$('#sort').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; $$('#sort button').forEach(x => x.classList.toggle('on', x === b)); S.sort = b.dataset.s; renderBrowse(); });
$('#tagbar').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; S.tag = b.dataset.tag; renderBrowse(); });
$('#refresh').onclick = () => loadAll();
document.addEventListener('click', e => {
  const ins = e.target.closest('[data-install]');
  if (ins) { e.stopPropagation(); return installModule(ins.dataset.install); }
  const rb = e.target.closest('[data-reboot]');
  if (rb) { e.stopPropagation(); return rebootPrompt(); }
  const op = e.target.closest('[data-open]');
  const c = op || e.target.closest('.card[data-id]');
  if (c && !e.target.closest('.sheet')) openDetail(op ? op.dataset.open : c.dataset.id);
});
$('#updAll').onclick = async () => {
  const ups = updates();
  if (!(await confirmSheet('Update all', `Install ${ups.length} updates one after another?`, 'Update all'))) return;
  for (const m of ups) await installModule(m.id, null, true);
  rebootPrompt();
};
$$('nav.bottom button').forEach(b => b.onclick = () => {
  S.tab = b.dataset.tab;
  $$('nav.bottom button').forEach(x => x.classList.toggle('on', x === b));
  $$('.tab').forEach(t => t.classList.toggle('active', t.id === 'tab-' + S.tab));
  window.scrollTo(0, 0);
  if (S.tab === 'settings') renderSettings();
});

/* ---------- details ---------- */
async function getDetail(m) {
  if (S.details.has(m.id)) return S.details.get(m.id);
  const url = absUrl(m._src, m.detail || `api/v1/modules/${m.id}.json`);
  const d = await getJSON(url);
  S.details.set(m.id, d);
  return d;
}
function pickRelease(d) {
  const rels = (d.releases || []).filter(r => r.zip && r.zip.url);
  const sv = d.stable && d.stable.versionCode;
  return rels.find(r => r.versionCode === sv && !r.prerelease) || rels.find(r => !r.prerelease) || rels[0];
}
function compat(d) {
  const w = [], c = d.compatibility || {}, sdk = +S.tools.sdk || 0;
  if (c.androidMinApi && sdk && sdk < c.androidMinApi) w.push(`Needs Android API ${c.androidMinApi}+, this device is API ${sdk}.`);
  if (c.androidMaxApi && sdk && sdk > c.androidMaxApi) w.push(`Declared for Android API ${c.androidMaxApi} or lower, this device is API ${sdk}.`);
  const abis = String(S.tools.abis || S.tools.abi || '').split(',').filter(Boolean);
  if (c.architectures && c.architectures.length && abis.length && !c.architectures.some(a => abis.includes(a))) w.push(`Built for ${c.architectures.join(', ')}, this device is ${abis.join(', ')}.`);
  if (d.metamodule) {
    const other = [...S.installed.values()].filter(i => i.meta && i.id !== d.id && i.state !== 'remove');
    if (other.length) w.push(`This is a metamodule and ${other.map(o => o.name || o.id).join(', ')} is already installed. Two metamodules at once usually cause a bootloop.`);
  }
  if (d.health && d.health.status && d.health.status !== 'ok') w.push(`The catalog reports this module as "${d.health.status}".`);
  return w;
}
async function openDetail(id) {
  const m = S.byId.get(id); if (!m) return;
  openSheet(`<div class="empty"><span class="spin"></span> Loading ${esc(m.name || m.id)}</div>`);
  let d;
  try { d = await getDetail(m); } catch (e) { openSheet(`<h2>${esc(m.name || m.id)}</h2><div class="err">Could not load module details (${esc(e.message)}).</div>`); return; }
  const i = S.installed.get(id), warns = compat(d);
  const rels = (d.releases || []).filter(r => r.zip && (PREF.pre || !r.prerelease));
  const links = [['Homepage', d.homepage], ['Support', d.support], ['Source', d.source && d.source.url]].filter(l => l[1] && VALID_URL.test(l[1]));
  const ch = rels[0] ? htmlToText(rels[0].changelogHtml) : '';
  openSheet(`
    <div style="display:flex;gap:12px;align-items:center">${iconHtml(m)}<div class="meta"><h2>${esc(d.name || id)}</h2><div class="by">${esc(authorsText(d))}</div></div></div>
    <p class="hint" style="margin-top:10px">${esc(d.summary || '')}</p>
    ${warns.map(w => `<div class="warn">${esc(w)}</div>`).join('')}
    <div class="row">${(d.tags || []).map(t => `<span class="chip">${esc(t)}</span>`).join('')}${d.metamodule ? '<span class="chip meta">Metamodule</span>' : ''}${d.license ? `<span class="chip">${esc(d.license)}</span>` : ''}${d.stars ? `<span class="chip">★ ${d.stars}</span>` : ''}</div>
    <div class="row" style="margin-top:12px">${i ? `<span class="hint" style="margin:0">Installed ${esc(i.version)}${i.pending ? ' (reboot pending)' : ''}</span>` : ''}${actionBtn(m)}</div>
    ${ch ? `<h4>What's new in ${esc(rels[0].version)}</h4><div class="prose">${esc(ch)}</div>` : ''}
    <h4>Versions</h4>
    <div>${rels.length ? rels.slice(0, 15).map(r => `<div class="rel"><div class="meta"><div class="name">${esc(r.version)}${r.prerelease ? ' <span class="chip meta">pre-release</span>' : ''}${r.immutable ? ' <span class="chip">immutable</span>' : ''}</div><div class="by">${esc(ago(r.publishedAt))} · ${esc(fmtSize(r.zip.size))}</div><div class="mono" style="color:var(--mu)">sha256 ${esc((r.zip.sha256 || 'not provided').slice(0, 24))}...</div></div><button class="ghost" data-rel="${esc(r.tag)}">Install</button></div>`).join('') : '<div class="hint">No downloadable releases.</div>'}</div>
    <h4>Details</h4>
    <div class="kv"><span>ID</span><span class="mono">${esc(id)}</span>${d.compatibility && d.compatibility.androidMinApi ? `<span>Min Android API</span><span>${esc(d.compatibility.androidMinApi)}</span>` : ''}${d.compatibility && d.compatibility.architectures ? `<span>Architectures</span><span>${esc(d.compatibility.architectures.join(', '))}</span>` : ''}<span>Source</span><span>${esc(d.source ? d.source.fullName : m._src)}</span><span>Catalog</span><span>${esc(m._src)}</span></div>
    ${links.length ? `<div class="row" style="margin-top:12px">${links.map(l => `<button class="ghost" data-link="${esc(l[1])}">${l[0]}</button>`).join('')}${d.readme ? '<button class="ghost" id="readme">Description</button>' : ''}</div>` : ''}
    <div id="readmeBox"></div>`, s => {
    $$('[data-rel]', s).forEach(b => b.onclick = () => installModule(id, b.dataset.rel));
    $$('[data-link]', s).forEach(b => b.onclick = () => cli(`open ${q(b.dataset.link)}`));
    const rb = $('#readme', s);
    if (rb) rb.onclick = async () => {
      rb.disabled = true; $('#readmeBox', s).innerHTML = '<p class="hint"><span class="spin"></span> Loading</p>';
      try { const t = await getText(absUrl(m._src, d.readme)); let txt = t; try { const j = JSON.parse(t); txt = j.html || j.markdown || j.content || t; } catch (e) { } $('#readmeBox', s).innerHTML = `<h4>Description</h4><div class="prose">${esc(htmlToText(txt))}</div>`; }
      catch (e) { $('#readmeBox', s).innerHTML = '<div class="err">Could not load the description.</div>'; }
    };
  });
}

/* ---------- install ---------- */
function logSheet(title) {
  openSheet(`<h2>${esc(title)}</h2><p class="hint" id="jobState"><span class="spin"></span> Working</p><pre class="log" id="jobLog"></pre><div class="toolbar" id="jobBtns"></div>`);
  return {
    log: t => { const el = $('#jobLog'); if (el) { el.textContent = t; el.scrollTop = el.scrollHeight; } },
    state: (h) => { const el = $('#jobState'); if (el) el.innerHTML = h; },
    done: (ok) => { const el = $('#jobBtns'); if (!el) return; el.innerHTML = ok ? '<button class="primary" id="jbR" style="flex:1">Reboot now</button><button class="ghost" id="jbL" style="flex:1">Later</button>' : '<button class="ghost" id="jbL" style="flex:1">Close</button>'; const r = $('#jbR'); if (r) r.onclick = () => cli('reboot'); $('#jbL').onclick = closeSheet; }
  };
}
async function pollJob(id, ui, prefix) {
  for (let n = 0; n < 1200; n++) {
    await sleep(600);
    const j = await cliJSON(`job ${q(id)}`, { status: 'none', log: '' });
    ui.log(prefix + (j.log || ''));
    if (j.status !== 'running') return j;
  }
  return { status: 'fail', log: 'Timed out' };
}
async function webviewDownload(id, url, size, ui) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const buf = new Uint8Array(await res.arrayBuffer());
  if (size && buf.length !== size) throw new Error(`size ${buf.length}, expected ${size}`);
  const CH = 48 * 1024;
  for (let i = 0, k = 0; i < buf.length; i += CH, k++) {
    let bin = ''; const part = buf.subarray(i, i + CH);
    for (let j = 0; j < part.length; j++) bin += String.fromCharCode(part[j]);
    const r = await cliJSON(`chunk ${q(id)} ${k} ${q(btoa(bin))}`, { ok: false });
    if (!r.ok) throw new Error('could not write the file');
    ui.state(`<span class="spin"></span> Saving ${Math.min(100, Math.round((i + CH) / buf.length * 100))}%`);
  }
}
async function installModule(id, tag, quiet) {
  const m = S.byId.get(id); if (!m || S.busy.has(id)) return;
  if (!HAS_KSU) return toast('Open ORBIT from your root manager to install');
  let d;
  try { d = await getDetail(m); } catch (e) { return toast('Could not load module details'); }
  const rel = tag ? (d.releases || []).find(r => r.tag === tag) : pickRelease(d);
  if (!rel || !rel.zip || !VALID_URL.test(rel.zip.url)) return toast('No downloadable release');
  const warns = compat(d);
  if (!quiet && warns.length && !(await confirmSheet('Install anyway?', warns.join(' '), 'Install', true))) return;
  const sha = /^[0-9a-f]{64}$/.test(rel.zip.sha256 || '') ? rel.zip.sha256 : '-';
  if (!quiet && sha === '-' && !(await confirmSheet('No checksum', 'The catalog has no sha256 for this file, so it cannot be verified.', 'Install unverified', true))) return;
  S.busy.add(id); renderAll();
  const ui = logSheet(`${d.name || id} ${rel.version}`);
  let res = await cliJSON(`install ${q(id)} ${q(rel.zip.url)} ${sha}`, { ok: false, error: 'engine not reachable' });
  let j = res.ok ? await pollJob(id, ui, '') : { status: 'fail', log: res.error };
  if (j.status === 'nodl') {
    const prev = j.log + '\nRoot download tools failed, retrying through the WebView...\n';
    ui.log(prev);
    try {
      await webviewDownload(id, rel.zip.url, rel.zip.size, ui);
      res = await cliJSON(`install ${q(id)} local ${sha}`, { ok: false });
      j = res.ok ? await pollJob(id, ui, prev) : { status: 'fail', log: prev + 'Could not start the installer.' };
    } catch (e) { j = { status: 'fail', log: prev + 'WebView download failed: ' + e.message }; ui.log(j.log); }
  }
  S.busy.delete(id);
  const ok = j.status === 'ok';
  ui.state(ok ? '<span class="okc">Installed. Reboot to activate.</span>' : '<span class="badc">Install failed. See the log above.</span>');
  ui.done(ok);
  if (ok) S.pendingReboot = true;
  await loadInstalled(); renderAll();
  return ok;
}
function rebootPrompt() {
  openSheet('<h2>Reboot to apply</h2><p class="hint">Installed and updated modules become active after a reboot.</p><div class="toolbar"><button class="primary" id="rbN" style="flex:1">Reboot now</button><button class="ghost" id="rbL" style="flex:1">Later</button></div>', s => {
    $('#rbN', s).onclick = () => cli('reboot'); $('#rbL', s).onclick = closeSheet;
  });
}

/* ---------- settings ---------- */
function renderSettings() {
  const t = S.tools, yn = v => v ? '<span class="okc">yes</span>' : '<span class="badc">no</span>';
  $('#settingsBox').innerHTML = `
  <div class="box"><h3>Catalog sources</h3><p class="hint">One base URL per line. Each must serve the KernelSU Modules API (api/v1/modules.json). The first source wins when IDs collide.</p>
    <textarea id="srcs">${esc(S.sources.join('\n'))}</textarea>
    <div class="toolbar" style="margin-top:8px"><button class="ghost" id="srcReset">Reset</button><button class="primary" id="srcSave" style="flex:1">Save and reload</button></div></div>
  <div class="box"><h3>Featured author</h3><p class="hint">GitHub user or author name shown in the Featured tab.</p>
    <div class="toolbar"><input class="f" id="auth" value="${esc(PREF.author)}"><button class="ghost" id="authSave">Save</button></div></div>
  <div class="box"><h3>Versions</h3><div class="toolbar"><span>Show pre-releases in version lists</span><button class="ghost" id="preT">${PREF.pre ? 'On' : 'Off'}</button></div></div>
  <div class="box"><h3>Diagnostics</h3><div class="kv">
    <span>Installer</span><span>${esc(t.installer || 'unknown')}</span><span>curl</span><span>${yn(t.curl)}</span><span>busybox wget</span><span>${yn(t.wget)}</span>
    <span>WebView fallback</span><span>${yn(true)}</span><span>Android API</span><span>${esc(t.sdk || '-')}</span><span>ABI</span><span>${esc(t.abis || t.abi || '-')}</span><span>Device</span><span>${esc(t.device || '-')}</span></div>
    <div class="toolbar" style="margin-top:12px"><button class="ghost" id="rb" style="flex:1">Reboot</button></div></div>
  <div class="box"><h3>About</h3><div class="kv"><span>Version</span><span>v1.0.0</span><span>Author</span><span>kreza6173-pixel</span><span>Checks</span><span>sha256 of every ZIP is verified against the catalog before installing</span></div></div>`;
  const b = $('#settingsBox');
  $('#srcSave', b).onclick = async () => {
    const lines = $('#srcs', b).value.split('\n').map(s => s.trim()).filter(Boolean);
    const bad = lines.filter(l => !VALID_URL.test(l));
    if (bad.length) return toast('Only https URLs are allowed');
    await cli(`setsources ${q(btoa(lines.join('\n')))}`); S.details.clear(); toast('Sources saved'); loadAll();
  };
  $('#srcReset', b).onclick = () => { $('#srcs', b).value = DEFAULT_SOURCE; };
  $('#authSave', b).onclick = () => { PREF.author = $('#auth', b).value.trim(); renderMine(); toast('Saved'); };
  $('#preT', b).onclick = e => { PREF.pre = !PREF.pre; e.target.textContent = PREF.pre ? 'On' : 'Off'; };
  $('#rb', b).onclick = rebootPrompt;
}

loadAll();
